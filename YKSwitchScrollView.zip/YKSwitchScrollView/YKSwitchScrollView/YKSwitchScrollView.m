//
//  YKSwitchScrollView.m
//  栏目
//
//  Created by Gemini on 16/1/11.
//  Copyright (c) 2016年 lanqiao. All rights reserved.
//

#import "YKSwitchScrollView.h"
#define TOP_SCROLL_HEIGHT 40
#define BUTTON_TITLE_FONT [UIFont systemFontOfSize:15]
#define BTN_MARGIN 15
@interface YKSwitchScrollView()<UIScrollViewDelegate>
{
 int tag;//topScroll中已经选中的button的tag值
}
@property(nonatomic,strong)UIScrollView *topScrollView;
@property(nonatomic,strong)UIScrollView *contentScrollView;
@end

@implementation YKSwitchScrollView

//自封装view时，重写的方法是initWithFrame，initWithCoder，前者手写代码添加子view会进，后者用xib创建会进
/**我们的程序在没有使用xib时，初始化控件会调用initWithFrame*/
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        tag = 1;
        [self addSubview:self.topScrollView];
        
        [self addSubview:self.contentScrollView];
        
    }
    return self;
}

-(void)returnTopScrollView{

    //return _topScrollView;

}


/**我们的程序在使用xib时，初始化控件会调用initWithCoder，不会调用initWithFrame*/

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        
    }
    return self;
}

/**懒加载*/
-(UIScrollView *)topScrollView{
    
    if (!_topScrollView) {
        _topScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, TOP_SCROLL_HEIGHT)];
        //[_topScrollView setBackgroundColor:[UIColor redColor]];
    }
    return _topScrollView;
}
-(UIScrollView *)contentScrollView{
    
    if (!_contentScrollView) {
        
        _contentScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, TOP_SCROLL_HEIGHT, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-TOP_SCROLL_HEIGHT)];
        

    }
    return _contentScrollView;
}

-(void)refreshSubView{

    float btnWidthAndMargin = BTN_MARGIN;
   
    
    for (int i = 0; i<[_delegate numberOfYKSwitchScrollView:self]; i++) {
        
        
        UIViewController *controller = [_delegate controllerYKSwitchScrollView:self atIndex:i];
        
        CGRect frame = [controller.title boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, TOP_SCROLL_HEIGHT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:BUTTON_TITLE_FONT} context:nil];
        
        UIButton *titlebtn = [UIButton buttonWithType:UIButtonTypeCustom];
        titlebtn.frame = CGRectMake(btnWidthAndMargin, 0, frame.size.width, TOP_SCROLL_HEIGHT);
        titlebtn.tag = i+1;
        [titlebtn setTitle:controller.title forState:UIControlStateNormal];
        [titlebtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        
        [titlebtn setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
        
        titlebtn.titleLabel.font =BUTTON_TITLE_FONT;
        btnWidthAndMargin+=frame.size.width+BTN_MARGIN;
        [titlebtn addTarget:self action:@selector(clickTopScrollBtn:) forControlEvents:UIControlEventTouchUpInside];
        if (i == 0) {
            titlebtn.selected  = YES;
        }
        [_topScrollView addSubview:titlebtn];
        
        controller.view.frame = CGRectMake([UIScreen mainScreen].bounds.size.width*i, 0, self.contentScrollView.frame.size.width,self.contentScrollView.frame.size.height );
        
        [_contentScrollView addSubview:controller.view];
        
        
    }
    
    _topScrollView.contentSize = CGSizeMake(btnWidthAndMargin,TOP_SCROLL_HEIGHT);
    _contentScrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width*[_delegate numberOfYKSwitchScrollView:self],self.contentScrollView.frame.size.height);
    _topScrollView.showsVerticalScrollIndicator = NO;
    _topScrollView.showsHorizontalScrollIndicator = NO;
    _contentScrollView.showsVerticalScrollIndicator = NO;
    _contentScrollView.showsHorizontalScrollIndicator = NO;
    _contentScrollView.pagingEnabled = YES;
    
    self.contentScrollView.bounces = NO;//滑到边界时是否有弹簧效果（默认为YES）
    self.topScrollView.delegate = self;
    self.contentScrollView.delegate = self;


}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if ([scrollView isEqual:self.contentScrollView]) {
        int page = scrollView.contentOffset.x/[UIScreen mainScreen].bounds.size.width;
        
        UIButton *btn = (UIButton*)[self viewWithTag:page+1];
        UIButton *selectedbtn = (UIButton*)[self viewWithTag:tag];
        btn.selected = YES;
        
        if (tag !=page+1) {
            selectedbtn.selected = NO;
        }
        tag = page+1;
        
        [self matchBorder:btn];
    }
    
    
}

-(void)clickTopScrollBtn:(UIButton*)sender{
    //设置topScrollView的选中状态
    UIButton *btn = (UIButton*)[self viewWithTag:tag];
    if (sender.tag != tag) {
        btn.selected = NO;
    }
    if (!sender.selected) {
        sender.selected = YES;
    }else{
        sender.selected = NO;
    }
    tag = (int)sender.tag;
    
    self.contentScrollView.contentOffset = CGPointMake((sender.tag-1)*[UIScreen mainScreen].bounds.size.width, 0);
    
    [self matchBorder:sender];
    
    
}

-(void)matchBorder:(UIButton*)sender{
    
    if (sender.frame.origin.x+sender.frame.size.width>[UIScreen mainScreen].bounds.size.width) {
        _topScrollView.contentOffset = CGPointMake(sender.frame.origin.x+sender.frame.size.width-[UIScreen mainScreen].bounds.size.width, 0);
        
    }else{
        _topScrollView.contentOffset = CGPointMake(0, 0);
    }
    
}

@end
