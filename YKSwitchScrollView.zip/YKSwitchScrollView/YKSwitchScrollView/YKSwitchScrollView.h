//
//  YKSwitchScrollView.h
//  栏目
//
//  Created by Gemini on 16/1/11.
//  Copyright (c) 2016年 lanqiao. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YKSwitchScrollView;
@protocol YKSwitchScrollViewDelegate <NSObject>
@required
/**获取栏目的数量*/
-(NSInteger)numberOfYKSwitchScrollView:(YKSwitchScrollView*)switchScrollView;
/**获取每个栏目对应的Controller*/
-(UIViewController*)controllerYKSwitchScrollView:(YKSwitchScrollView*)switchScrollView atIndex:(NSInteger)index;

@optional

@end

@interface YKSwitchScrollView : UIView
@property(nonatomic,assign)id<YKSwitchScrollViewDelegate>delegate;
/*设置代理后加载子视图*/
-(void)refreshSubView;
@end
