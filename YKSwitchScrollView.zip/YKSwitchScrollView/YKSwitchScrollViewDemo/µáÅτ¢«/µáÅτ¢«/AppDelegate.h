//
//  AppDelegate.h
//  栏目
//
//  Created by Gemini on 16/1/10.
//  Copyright (c) 2016年 lanqiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

