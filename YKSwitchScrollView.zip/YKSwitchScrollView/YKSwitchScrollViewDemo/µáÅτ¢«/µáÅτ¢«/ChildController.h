//
//  ChildController.h
//  栏目
//
//  Created by Gemini on 16/1/11.
//  Copyright (c) 2016年 lanqiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildController : UIViewController

@end
