//
//  ViewController.m
//  栏目
//
//  Created by Gemini on 16/1/10.
//  Copyright (c) 2016年 lanqiao. All rights reserved.
//

#import "ViewController.h"
#define TOP_SCROLL_HEIGHT 40
#define BUTTON_TITLE_FONT [UIFont systemFontOfSize:16]
#define BTN_MARGIN 15
@interface ViewController ()<UIScrollViewDelegate>
{
    NSArray *titleArray;
    int tag;//topScroll中已经选中的button的tag值
    
}

@property(nonatomic,strong)UIScrollView *topScrollView;
@property(nonatomic,strong)UIScrollView *contentScrollView;
@end




@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    tag = 1;
    //关闭ios7之后的导航透明效果（扁平化设计），否则会导致scrollView里面的控件往下顶
    [self.navigationController.navigationBar setTranslucent:NO];
    
    titleArray = @[@"要闻",@"娱乐",@"汽车",@"生活",@"科技",@"母婴",@"家具"];
    
    [self.view addSubview:self.topScrollView];
    [self.view addSubview:self.contentScrollView];
    [self loadScrollView];
    
    
}
/**懒加载*/
-(UIScrollView *)topScrollView{

    if (!_topScrollView) {
        _topScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, TOP_SCROLL_HEIGHT)];
    }
    return _topScrollView;
}
-(UIScrollView *)contentScrollView{

    if (!_contentScrollView) {
        
        _contentScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, TOP_SCROLL_HEIGHT, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-TOP_SCROLL_HEIGHT)];
        
    }
    return _contentScrollView;
}

-(void)loadScrollView{

    float btnWidthAndMargin = BTN_MARGIN;
    NSArray *colorArr = @[[UIColor redColor],[UIColor blueColor],[UIColor greenColor],[UIColor orangeColor],[UIColor grayColor],[UIColor blackColor],[UIColor purpleColor]];
    
    for (int i = 0; i<titleArray.count; i++) {
        
        
        NSString *str = titleArray [i];
        CGRect frame = [str boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, TOP_SCROLL_HEIGHT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:BUTTON_TITLE_FONT} context:nil];
        
        UIButton *titlebtn = [UIButton buttonWithType:UIButtonTypeCustom];
        titlebtn.frame = CGRectMake(btnWidthAndMargin, 0, frame.size.width, TOP_SCROLL_HEIGHT);
        titlebtn.tag = i+1;
        [titlebtn setTitle:str forState:UIControlStateNormal];
        [titlebtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
       
        [titlebtn setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
        
        titlebtn.titleLabel.font =BUTTON_TITLE_FONT;
        btnWidthAndMargin+=frame.size.width+BTN_MARGIN;
        [titlebtn addTarget:self action:@selector(clickTopScrollBtn:) forControlEvents:UIControlEventTouchUpInside];
        if (i == 0) {
            titlebtn.selected  = YES;
        }
        [_topScrollView addSubview:titlebtn];
        
        UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width*i, 0, [UIScreen mainScreen].bounds.size.width, self.contentScrollView.frame.size.height)];
        int j = arc4random()%colorArr.count;
        [tableView setBackgroundColor:[colorArr objectAtIndex:j]];
        [_contentScrollView addSubview:tableView];
        
       
    }
    
    _topScrollView.contentSize = CGSizeMake(btnWidthAndMargin,TOP_SCROLL_HEIGHT);
    _contentScrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width*titleArray.count,self.contentScrollView.frame.size.height);
    _topScrollView.showsVerticalScrollIndicator = NO;
    _topScrollView.showsHorizontalScrollIndicator = NO;
    _contentScrollView.showsVerticalScrollIndicator = NO;
    _contentScrollView.showsHorizontalScrollIndicator = NO;
    _contentScrollView.pagingEnabled = YES;
    
    self.contentScrollView.bounces = NO;//滑到边界时是否有弹簧效果（默认为YES）
    self.topScrollView.delegate = self;
    self.contentScrollView.delegate = self;
    
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if ([scrollView isEqual:self.contentScrollView]) {
        int page = scrollView.contentOffset.x/[UIScreen mainScreen].bounds.size.width;
        
            UIButton *btn = (UIButton*)[self.view viewWithTag:page+1];
            UIButton *selectedbtn = (UIButton*)[self.view viewWithTag:tag];
            btn.selected = YES;
        
        if (tag !=page+1) {
            selectedbtn.selected = NO;
        }
            tag = page+1;
        
    [self matchBorder:btn];
    }
    
    
}

-(void)clickTopScrollBtn:(UIButton*)sender{
    //设置topScrollView的选中状态
    UIButton *btn = (UIButton*)[self.view viewWithTag:tag];
    if (sender.tag != tag) {
        btn.selected = NO;
    }
    if (!sender.selected) {
        sender.selected = YES;
    }else{
        sender.selected = NO;
    }
    tag = sender.tag;
    
    self.contentScrollView.contentOffset = CGPointMake((sender.tag-1)*[UIScreen mainScreen].bounds.size.width, 0);
    
    [self matchBorder:sender];
    
    
}

-(void)matchBorder:(UIButton*)sender{
    
    if (sender.frame.origin.x+sender.frame.size.width>[UIScreen mainScreen].bounds.size.width) {
        _topScrollView.contentOffset = CGPointMake(sender.frame.origin.x+sender.frame.size.width-[UIScreen mainScreen].bounds.size.width, 0);
        
    }else{
        _topScrollView.contentOffset = CGPointMake(0, 0);
    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
