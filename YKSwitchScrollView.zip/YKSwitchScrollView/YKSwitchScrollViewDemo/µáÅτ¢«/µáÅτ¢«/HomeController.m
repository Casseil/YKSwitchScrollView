//
//  HomeController.m
//  栏目
//
//  Created by Gemini on 16/1/11.
//  Copyright (c) 2016年 lanqiao. All rights reserved.
//

#import "HomeController.h"
#import "YKSwitchScrollView.h"
#import "ChildController.h"
@interface HomeController ()<YKSwitchScrollViewDelegate>
{

     NSArray *titleArray;
}
@property (nonatomic,strong)NSMutableArray *controllerArray;
@end

@implementation HomeController
/*懒加载*/
-(NSMutableArray *)controllerArray{
    if (_controllerArray == nil) {
        _controllerArray = [NSMutableArray array];
    }
    return _controllerArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setTranslucent:NO];
    YKSwitchScrollView *switchScrollView = [[YKSwitchScrollView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:switchScrollView];
    
     NSArray *colorArr = @[[UIColor redColor],[UIColor blueColor],[UIColor greenColor],[UIColor orangeColor],[UIColor grayColor],[UIColor blackColor],[UIColor purpleColor]];
    titleArray = @[@"今日要闻",@"娱乐",@"汽车",@"生活",@"科技",@"母婴",@"家具"];
    
    for (NSString*str in titleArray) {
        ChildController *childController = [[ChildController alloc]init];
        int j = arc4random()%colorArr.count;
        childController.title = str;
        [childController.view setBackgroundColor:[colorArr objectAtIndex:j]];
        [self.controllerArray addObject:childController];

    }
    
    
    switchScrollView.delegate = self;
    //刷新子视图
    [switchScrollView refreshSubView];
    
}
#pragma mark YKSwitchScrollViewDelegate
-(NSInteger)numberOfYKSwitchScrollView:(YKSwitchScrollView *)switchScrollView{
    return self.controllerArray.count;

}
-(UIViewController *)controllerYKSwitchScrollView:(YKSwitchScrollView *)switchScrollView atIndex:(NSInteger)index{

    return [self.controllerArray objectAtIndex:index];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
